#pragma once
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

void node_proto_register_callbacks(void);
void node_proto_client_start(const char *host, uint16_t port);
void node_proto_start_tasks(void);
void node_proto_start_root_tasks(void);
void node_handle_local_cmd(const char *cmd);

/* === FIX WAIT-NODE-RUNNING: форсировать немедленный STATUS ===
   Вызывается после traffic_light_start(), чтобы ROOT узнал
   о RUNNING без ожидания NODE_STATUS_PERIOD_MS (10 с). */
void node_send_status_now(void);
/* === END FIX WAIT-NODE-RUNNING === */

#ifdef __cplusplus
}
#endif