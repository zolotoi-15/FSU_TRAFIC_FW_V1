#pragma once
#include <stdbool.h>
#include <stddef.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*transport_rx_cb_t)(const char *data, size_t len);

esp_err_t transport_init(void);
bool      transport_is_lora(void);
bool      transport_is_tcp(void);

esp_err_t transport_send_cmd(const char *cmd, size_t len);
/* === FIX SYNC-NO-WAIT ===
   Идемпотентные команды (sync:, traffic:start, traffic:stop, ping)
   шлются БЕЗ ACK. Потеря лечится fallback 30 с, force_resync_pending
   и watchdog-ом. ACK на них только блокирует ROOT на 2000 мс × 2
   retry, из-за чего apply_ms уезжает в прошлое и lag на ROOT
   растёт до 1498 мс (см. логи). === */
esp_err_t transport_send_cmd_noack(const char *cmd, size_t len);
/* === END FIX SYNC-NO-WAIT === */

esp_err_t transport_send_cfg(const char *json, size_t len);
esp_err_t transport_send_status(const char *json, size_t len);
esp_err_t transport_send_evt(const char *evt, size_t len);

void transport_set_cmd_cb(transport_rx_cb_t cb);
void transport_set_cfg_cb(transport_rx_cb_t cb);
void transport_set_status_cb(transport_rx_cb_t cb);
void transport_set_evt_cb(transport_rx_cb_t cb);

void transport_force_lora(void);
void transport_force_tcp(void);

/* Сброс accum_cfg на приёмнике (по cfg:reset) */
void transport_reset_cfg_accum(void);

/* NODE приостанавливает STATUS во время приёма CFG.
   === FIX: учитывает s_cfg_expected (после cfg:reset) === */
bool transport_is_cfg_rx_in_progress(void);
bool transport_is_tx_idle(void);

/* === FIX: сброс флага ожидания CFG после успешного приёма === */
void transport_clear_cfg_expected(void);

#ifdef __cplusplus
}
#endif